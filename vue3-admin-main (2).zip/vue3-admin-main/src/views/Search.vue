<template>
  <div class="search">
    <el-button type="primary" @click="search">查询</el-button>
    <el-table
      :data="data1"
      :default-sort="{ prop: 'data1', order: 'descending' }"
      style="width: 100%"
    >
      <el-table-column prop="code" label="Code" width="180" />
      <el-table-column prop="name" label="Name" width="180" />
      <el-table-column prop="jlr_shishi" label="净流入" sortable />
    </el-table>
  </div>
</template>

<script>
import { onMounted, reactive, ref, toRefs } from "vue";
import axios from "@/utils/axios";
import data from "../assets/json/symbol";
// import axios from 'axios'
// import { ElMessage } from 'element-plus'
export default {
  name: "Search",
  setup() {
    const data1 = ref([]);
    const data2 = ref([]);
    onMounted(() => {
      axios
        .get(
          "http://quotes.money.163.com/hs/service/marketradar_ajax.php?host=http%3A%2F%2Fquotes.money.163.com%2Fhs%2Fservice%2Fmarketradar_ajax.php&page=0&query=STYPE%3AEQA&types=&count=28&type=query&order=desc"
        )
        .then((res) => {
          console.log(res.list);
          data2.value = res.list;
        });
      // console.log(data);
    });
    const search = () => {
      data1.value = [];
      // data.data.forEach((item) => {
      //   let code = item[0];
      //   let name = item[1];
      //   let url = `http://quotes.money.163.com/service/zjlx_chart.html?symbol=${code}`;
      //   axios.get(url).then((res) => {
      //     let info = {
      //       name: name,
      //       code: code,
      //       jlr_shishi: res.jlr_shishi,
      //     };
      //     console.log(info);
      //     data1.value.push(info);
      //   });
      // });

      data2.value.forEach((item) => {
        let code = item.SYMBOL;
        let name = item.NAME;
        let url = `http://quotes.money.163.com/service/zjlx_chart.html?symbol=${code}`;
        axios.get(url).then((res) => {
          let info = {
            name: name,
            code: code,
            jlr_shishi: Number(res.jlr_shishi.replace(",","")),
          };
          // console.log(info);
          data1.value.push(info);
        });
      });
    };
    return {
      // ...toRefs(state),
      data1,
      search,
    };
  },
};
</script>

<style>
.search {
  margin-bottom: 20px;
}
</style>
